# Gas El Volcán - Evaluación Parcial 1

Proyecto académico para DSY1104.

Tecnologías:
- HTML5
- CSS externo
- JavaScript Vanilla
- Node.js para servidor local

## Ejecutar

1. Abrir la carpeta en Visual Studio Code.
2. Abrir una terminal en la carpeta.
3. Ejecutar `npm start`.
4. Abrir `http://localhost:3000`.

No utiliza React ni frameworks de frontend. El carrito utiliza localStorage.


## Módulo de pedidos y entregas

El proyecto ahora incluye:
- Creación de pedidos sin llamada telefónica.
- Seguimiento del pedido en `seguimiento.html` con actualización automática mediante `storage`/`BroadcastChannel`.
- Panel de operadora en `admin/pedidos.html`.
- Vista móvil de repartidor en `repartidor.html`.
- Estados: RECIBIDO, CONFIRMADO, EN_PREPARACION, ASIGNADO, EN_CAMINO y ENTREGADO.
- Descuento automático de stock al crear el pedido.
- Registro automático del pago al confirmar la entrega.

### Usuarios demo
- `admin@gmail.com` → Administrador
- `operadora@duoc.cl` → Operadora / Despachadora
- `repartidor@gmail.com` → Repartidor

Para probar el tiempo real, abre dos pestañas del mismo proyecto: seguimiento del cliente en una y `admin/pedidos.html`/`repartidor.html` en otra. Los cambios de estado se sincronizan automáticamente.
