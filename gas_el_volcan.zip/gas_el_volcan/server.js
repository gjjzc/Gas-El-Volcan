const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const PORT = 3000;
const ROOT = __dirname;
const DB_DIR = path.join(ROOT, 'data');
const PEDIDOS_FILE = path.join(DB_DIR, 'pedidos.json');
const PAGOS_FILE = path.join(DB_DIR, 'pagos.json');

const MIME = {
  '.html': 'text/html; charset=UTF-8',
  '.css': 'text/css; charset=UTF-8',
  '.js': 'text/javascript; charset=UTF-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.json': 'application/json; charset=UTF-8'
};

if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
if (!fs.existsSync(PEDIDOS_FILE)) fs.writeFileSync(PEDIDOS_FILE, '[]', 'utf8');
if (!fs.existsSync(PAGOS_FILE)) fs.writeFileSync(PAGOS_FILE, '[]', 'utf8');

function leerJSON(archivo) {
  try { return JSON.parse(fs.readFileSync(archivo, 'utf8')); }
  catch (error) { return []; }
}

function guardarJSON(archivo, datos) {
  fs.writeFileSync(archivo, JSON.stringify(datos, null, 2), 'utf8');
}

function responderJSON(res, codigo, datos) {
  res.writeHead(codigo, {
    'Content-Type': 'application/json; charset=UTF-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.end(JSON.stringify(datos));
}

function cuerpoJSON(req) {
  return new Promise((resolve, reject) => {
    let cuerpo = '';
    req.on('data', (fragmento) => {
      cuerpo += fragmento;
      if (cuerpo.length > 2_000_000) req.destroy();
    });
    req.on('end', () => {
      try { resolve(cuerpo ? JSON.parse(cuerpo) : {}); }
      catch (error) { reject(error); }
    });
    req.on('error', reject);
  });
}

async function manejarAPI(req, res, pathname) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    res.end();
    return true;
  }

  if (pathname === '/api/pedidos' && req.method === 'GET') {
    responderJSON(res, 200, leerJSON(PEDIDOS_FILE));
    return true;
  }

  if (pathname === '/api/pedidos' && req.method === 'POST') {
    try {
      const pedido = await cuerpoJSON(req);
      const pedidos = leerJSON(PEDIDOS_FILE);
      const indice = pedidos.findIndex((item) => item.id === pedido.id);
      if (indice >= 0) pedidos[indice] = pedido;
      else pedidos.unshift(pedido);
      guardarJSON(PEDIDOS_FILE, pedidos);
      responderJSON(res, 201, pedido);
    } catch (error) {
      responderJSON(res, 400, { error: 'Pedido inválido.' });
    }
    return true;
  }

  const coincidenciaPedido = pathname.match(/^\/api\/pedidos\/([^/]+)$/);
  if (coincidenciaPedido && req.method === 'PUT') {
    try {
      const id = decodeURIComponent(coincidenciaPedido[1]);
      const cambios = await cuerpoJSON(req);
      const pedidos = leerJSON(PEDIDOS_FILE);
      const indice = pedidos.findIndex((item) => item.id === id);
      if (indice < 0) {
        responderJSON(res, 404, { error: 'Pedido no encontrado.' });
        return true;
      }
      pedidos[indice] = { ...pedidos[indice], ...cambios };
      guardarJSON(PEDIDOS_FILE, pedidos);
      responderJSON(res, 200, pedidos[indice]);
    } catch (error) {
      responderJSON(res, 400, { error: 'Actualización inválida.' });
    }
    return true;
  }

  if (pathname === '/api/pagos' && req.method === 'GET') {
    responderJSON(res, 200, leerJSON(PAGOS_FILE));
    return true;
  }

  if (pathname === '/api/pagos' && req.method === 'POST') {
    try {
      const pago = await cuerpoJSON(req);
      const pagos = leerJSON(PAGOS_FILE);
      if (!pagos.some((item) => item.pedidoId === pago.pedidoId)) pagos.push(pago);
      guardarJSON(PAGOS_FILE, pagos);
      responderJSON(res, 201, pago);
    } catch (error) {
      responderJSON(res, 400, { error: 'Pago inválido.' });
    }
    return true;
  }

  return false;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const urlPath = decodeURIComponent(url.pathname);

  if (urlPath.startsWith('/api/')) {
    const atendida = await manejarAPI(req, res, urlPath);
    if (atendida) return;
  }

  let ruta = urlPath === '/' ? '/index.html' : urlPath;
  const filePath = path.join(ROOT, ruta);

  if (!filePath.startsWith(ROOT) || !fs.existsSync(filePath)) {
    res.writeHead(404, { 'Content-Type': 'text/html; charset=UTF-8' });
    res.end('<h1>404 - Página no encontrada</h1>');
    return;
  }

  let resolvedPath = filePath;
  if (fs.statSync(resolvedPath).isDirectory()) resolvedPath = path.join(resolvedPath, 'index.html');

  if (!resolvedPath.startsWith(ROOT) || !fs.existsSync(resolvedPath) || fs.statSync(resolvedPath).isDirectory()) {
    res.writeHead(404, { 'Content-Type': 'text/html; charset=UTF-8' });
    res.end('<h1>404 - Página no encontrada</h1>');
    return;
  }

  const ext = path.extname(resolvedPath).toLowerCase();
  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Cache-Control': 'no-store'
  });
  fs.createReadStream(resolvedPath).pipe(res);
});

server.listen(PORT, () => {
  console.log(`Gas El Volcán funcionando en http://localhost:${PORT}`);
});
