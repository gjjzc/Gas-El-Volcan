/* ============================================================
   GAS EL VOLCÁN — script.js
   ------------------------------------------------------------
   Índice de este archivo (para ubicarse rápido):
     1. Datos iniciales del catálogo (respaldo local)
     2. Acceso a datos guardados (localStorage)
     3. Utilidades generales (formato de precio, typeof, etc.)
     4. Sistema de notificaciones (reemplaza a alert())
     5. Menú de navegación (mobile)
     6. Render de productos (listado, destacados, detalle)
     7. Carrito de compras
     8. Validación de formularios (login, registro, contacto...)
     9. Región / comuna dependientes
    10. Panel administrador (productos y usuarios)
    11. Delegación de eventos (reemplaza a los onclick="")
    12. Carga asíncrona del catálogo (fetch + async/await)
    13. Arranque de la aplicación (DOMContentLoaded)

   Dónde se usa cada tema de la guía HTML/CSS/JS:
     - const / let, arrow functions       -> en todo el archivo
     - array: map/filter/reduce/find/push -> sección 6, 7 y 10
     - DOM: querySelector, classList,
       createElement, append, textContent -> secciones 4, 8, 11
     - Eventos: addEventListener,
       event.target, preventDefault       -> secciones 5, 8, 11
     - Promise, async/await, fetch, try/catch -> secciones 7 y 12
     - typeof                             -> sección 3 (esNumeroValido)
   ============================================================ */


/* ------------------------------------------------------------
   1. DATOS INICIALES DEL CATÁLOGO
   Este arreglo es el respaldo que se usa si todavía no se pudo
   cargar el catálogo desde data/productos.json (ver sección 12).
   ------------------------------------------------------------ */

/* Cada vez que cambies data/productos.json (nuevos productos, precios,
   o —como acá— rutas de imágenes corregidas), sube este número. Así el
   navegador del cliente sabe que su copia en localStorage quedó vieja
   y vuelve a pedir el catálogo al servidor en vez de seguir usando la
   versión cacheada. */
const CATALOGO_VERSION = "2";

const productosIniciales = [
  { id: "CL001", categoria: "Cilindros de Gas", nombre: "Cilindro GLP 5 kg", descripcion: "Cilindro de gas licuado de petróleo 5 kg. Para uso residencial (cocina, calefacción pequeña).", precio: 6500, precioComercial: 6000, stock: 80, imagen: "img/cilindro5K.webp" },
  { id: "CL002", categoria: "Cilindros de Gas", nombre: "Cilindro GLP 11 kg", descripcion: "Cilindro estándar doméstico. El más utilizado en hogares chilenos. Compatible con reguladores estándar.", precio: 12000, precioComercial: 11000, stock: 200, imagen: "img/cilindro11K.webp" },
  { id: "CL003", categoria: "Cilindros de Gas", nombre: "Cilindro GLP 15 kg", descripcion: "Cilindro de mayor capacidad para hogares de alto consumo o locales pequeños.", precio: 16000, precioComercial: 14500, stock: 90, imagen: "img/cilindro15K.jpg" },
  { id: "CL004", categoria: "Cilindros de Gas", nombre: "Cilindro GLP 45 kg", descripcion: "Cilindro industrial. Uso comercial: restaurantes, talleres y calefacción de locales.", precio: 45000, precioComercial: 40000, stock: 30, imagen: "img/cilindro45K.webp" },
  { id: "RG001", categoria: "Reguladores", nombre: "Regulador doméstico estándar", descripcion: "Regulador de 1 etapa para cilindros 5, 11 y 15 kg. Presión de salida 28 mbar.", precio: 8990, precioComercial: 8200, stock: 45, imagen: "img/reguladorEstandar.webp" },
  { id: "RG002", categoria: "Reguladores", nombre: "Regulador de alta presión", descripcion: "Regulador para cocinas industriales o equipos de mayor consumo. Presión regulable.", precio: 18990, precioComercial: 17000, stock: 12, imagen: "img/reguladorGasAPresion.webp" },
  { id: "RG003", categoria: "Reguladores", nombre: "Regulador dual (2 salidas)", descripcion: "Permite conectar dos artefactos simultáneamente al mismo cilindro.", precio: 14990, precioComercial: 13500, stock: 18, imagen: "img/regulador2Salidas.webp" },
  { id: "MG001", categoria: "Mangueras y Conexiones", nombre: "Manguera gas 1.5 m", descripcion: "Manguera flexible homologada. Diámetro interior 9mm. Compatible con reguladores estándar.", precio: 3990, precioComercial: 3500, stock: 80, imagen: "img/mangera1.5m.webp" },
  { id: "MG002", categoria: "Mangueras y Conexiones", nombre: "Manguera gas 3 m", descripcion: "Manguera larga para instalaciones donde el artefacto está alejado del cilindro.", precio: 6990, precioComercial: 6200, stock: 50, imagen: "img/mangera3m.webp" },
  { id: "MG003", categoria: "Mangueras y Conexiones", nombre: "Abrazadera metálica", descripcion: "Abrazadera de acero para asegurar la conexión manguera-regulador y manguera-artefacto.", precio: 990, precioComercial: 800, stock: 200, imagen: "img/abrazadera-metalica.jpg" },
  { id: "MG004", categoria: "Mangueras y Conexiones", nombre: "Kit conexión completo", descripcion: "Regulador + manguera 1.5 m + abrazaderas. Todo lo necesario para instalar un cilindro nuevo.", precio: 12990, precioComercial: 11500, stock: 25, imagen: "img/kitCompleto.webp" },
  { id: "AC001", categoria: "Accesorios", nombre: "Carro porta cilindro 11/15 kg", descripcion: "Carro metálico con ruedas para transportar cilindros dentro del hogar con seguridad.", precio: 12990, precioComercial: 11000, stock: 20, imagen: "img/carroPortaGas.webp" },
  { id: "AC002", categoria: "Accesorios", nombre: "Tapa protectora para válvula", descripcion: "Tapa de plástico ABS para proteger la válvula del cilindro durante el transporte.", precio: 1490, precioComercial: 1200, stock: 60, imagen: "img/tapaValvula.jpg" },
  { id: "AC003", categoria: "Accesorios", nombre: "Detector de gas a batería", descripcion: "Sensor electroquímico. Alarma sonora y visual ante fuga de gas GLP o metano.", precio: 19990, precioComercial: 17000, stock: 8, imagen: "img/detectorDeGas.webp" }
];


/* ------------------------------------------------------------
   2. ACCESO A DATOS GUARDADOS (localStorage)
   ------------------------------------------------------------ */

function obtenerProductos() {
  const guardados = localStorage.getItem("productosGas");
  return guardados ? JSON.parse(guardados) : productosIniciales;
}

function guardarProductos(productos) {
  localStorage.setItem("productosGas", JSON.stringify(productos));
}

function obtenerCarrito() {
  const guardado = localStorage.getItem("carritoGas");
  return guardado ? JSON.parse(guardado) : [];
}

function guardarCarrito(carrito) {
  localStorage.setItem("carritoGas", JSON.stringify(carrito));
  actualizarContador();
}

function obtenerUsuarios() {
  const guardado = localStorage.getItem("usuariosGas");
  return guardado ? JSON.parse(guardado) : [];
}

function guardarUsuarios(usuarios) {
  localStorage.setItem("usuariosGas", JSON.stringify(usuarios));
}


/* ------------------------------------------------------------
   3. UTILIDADES GENERALES
   ------------------------------------------------------------ */

/** Da formato de pesos chilenos a un número: 12000 -> "$12.000" */
function formatoPrecio(valor) {
  return "$" + Number(valor).toLocaleString("es-CL");
}

/**
 * Verifica que un valor sea realmente un número utilizable
 * (ni texto, ni vacío, ni NaN). Usa el operador typeof, que es
 * la forma estándar de consultar el tipo de un valor en JS.
 */
function esNumeroValido(valor) {
  const numero = Number(valor);
  return typeof numero === "number" && !Number.isNaN(numero);
}

/** Pausa la ejecución "ms" milisegundos. Devuelve una Promise. */
function esperar(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}


/* ------------------------------------------------------------
   4. SISTEMA DE NOTIFICACIONES (reemplaza a los alert())
   Usa document.createElement(), classList y append() en vez de
   innerHTML, porque el mensaje puede incluir datos que en el
   futuro vengan de un formulario (buena práctica de seguridad).
   ------------------------------------------------------------ */

function obtenerContenedorNotificaciones() {
  let contenedor = document.querySelector(".notificaciones");
  if (!contenedor) {
    contenedor = document.createElement("div");
    contenedor.className = "notificaciones";
    document.body.append(contenedor);
  }
  return contenedor;
}

function mostrarNotificacion(mensaje, tipo = "info") {
  const contenedor = obtenerContenedorNotificaciones();

  const aviso = document.createElement("div");
  aviso.className = "notificacion" + (tipo === "error" ? " error" : "");
  aviso.textContent = mensaje; // textContent: nunca interpreta HTML

  contenedor.append(aviso);

  // Se muestra con una transición y se retira sola después de un rato
  requestAnimationFrame(() => aviso.classList.add("visible"));
  setTimeout(() => {
    aviso.classList.remove("visible");
    setTimeout(() => aviso.remove(), 250);
  }, 2600);
}


/* ------------------------------------------------------------
   5. MENÚ DE NAVEGACIÓN (mobile)
   ------------------------------------------------------------ */

function activarMenu() {
  const boton = document.querySelector(".hamburguesa");
  const menu = document.querySelector(".menu");
  if (!boton || !menu) return;

  boton.addEventListener("click", () => {
    menu.classList.toggle("abierto");
  });
}

function actualizarContador() {
  const totalItems = obtenerCarrito().reduce((suma, item) => suma + item.cantidad, 0);
  document.querySelectorAll(".contador-carrito").forEach((elemento) => {
    elemento.textContent = totalItems;
  });
}


/* ------------------------------------------------------------
   6. RENDER DE PRODUCTOS (listado, destacados y detalle)
   ------------------------------------------------------------ */

/**
 * Genera el HTML de una tarjeta de producto.
 * Se usa innerHTML porque el contenido sale de nuestro propio
 * catálogo (no de un formulario ni de otro usuario), así que no
 * hay riesgo de inyectar HTML no confiable (ver guía, sección 29).
 */
function tarjetaProducto(producto) {
  return `
    <article class="tarjeta">
      <a href="detalle.html?id=${producto.id}">
        <img src="${producto.imagen}" alt="${producto.nombre}">
      </a>
      <div class="contenido">
        <span class="categoria">${producto.categoria}</span>
        <h3>${producto.nombre}</h3>
        <p>${producto.descripcion}</p>
        <div class="precio">${formatoPrecio(producto.precio)}</div>
        <small>Stock disponible: ${producto.stock}</small>
        <div class="acciones-card">
          <a class="btn btn-secundario" href="detalle.html?id=${producto.id}">Ver detalle</a>
          <button class="btn btn-principal" data-accion="agregar-carrito" data-id="${producto.id}">
            Añadir
          </button>
        </div>
      </div>
    </article>
  `;
}

function renderDestacados() {
  const contenedor = document.getElementById("lista-destacados");
  if (!contenedor) return;

  const destacados = obtenerProductos().slice(0, 4);
  contenedor.innerHTML = destacados.map(tarjetaProducto).join("");
}

function renderProductos() {
  const contenedor = document.getElementById("lista-productos");
  if (!contenedor) return;

  const productos = obtenerProductos();
  const selectorCategoria = document.getElementById("filtro-categoria");
  const buscador = document.getElementById("buscar-producto");

  function pintarLista() {
    let lista = productos;

    const categoriaElegida = selectorCategoria ? selectorCategoria.value : "Todas";
    if (categoriaElegida !== "Todas") {
      lista = lista.filter((producto) => producto.categoria === categoriaElegida);
    }

    const textoBusqueda = buscador ? buscador.value.trim().toLowerCase() : "";
    if (textoBusqueda) {
      lista = lista.filter((producto) =>
        producto.nombre.toLowerCase().includes(textoBusqueda) ||
        producto.descripcion.toLowerCase().includes(textoBusqueda)
      );
    }

    contenedor.innerHTML = lista.length
      ? lista.map(tarjetaProducto).join("")
      : '<div class="vacio">No se encontraron productos.</div>';
  }

  if (selectorCategoria) selectorCategoria.addEventListener("change", pintarLista);
  if (buscador) buscador.addEventListener("input", pintarLista);

  pintarLista();
}

function renderDetalle() {
  const contenedor = document.getElementById("detalle-producto");
  if (!contenedor) return;

  const idBuscado = new URLSearchParams(location.search).get("id") || "CL002";
  const productos = obtenerProductos();
  const producto = productos.find((item) => item.id === idBuscado) || productos[0];

  contenedor.innerHTML = `
    <div class="detalle-imagen">
      <img src="${producto.imagen}" alt="${producto.nombre}">
    </div>
    <div>
      <span class="categoria">${producto.categoria}</span>
      <h1>${producto.nombre}</h1>
      <p>${producto.descripcion}</p>
      <div class="precio">${formatoPrecio(producto.precio)}</div>
      <p><strong>Stock:</strong> ${producto.stock} unidades</p>

      <div class="cantidad">
        <label for="cantidad">Cantidad:</label>
        <input id="cantidad" type="number" min="1" max="${producto.stock}" value="1">
      </div>

      <button class="btn btn-principal" data-accion="agregar-desde-detalle" data-id="${producto.id}">
        Añadir al carrito
      </button>
      <a class="btn btn-secundario" href="productos.html">Volver a productos</a>
    </div>
  `;
}


/* ------------------------------------------------------------
   7. CARRITO DE COMPRAS
   ------------------------------------------------------------ */

function agregarCarrito(id, cantidad = 1) {
  const producto = obtenerProductos().find((item) => item.id === id);
  if (!producto) return;

  if (!esNumeroValido(cantidad) || cantidad < 1 || cantidad > producto.stock) {
    mostrarNotificacion("La cantidad solicitada no está disponible.", "error");
    return;
  }

  const carrito = obtenerCarrito();
  const itemExistente = carrito.find((item) => item.id === id);

  if (itemExistente) {
    if (itemExistente.cantidad + cantidad > producto.stock) {
      mostrarNotificacion("No hay suficiente stock para agregar esa cantidad.", "error");
      return;
    }
    itemExistente.cantidad += cantidad;
  } else {
    carrito.push({
      id: producto.id,
      nombre: producto.nombre,
      precio: producto.precio,
      imagen: producto.imagen,
      cantidad
    });
  }

  guardarCarrito(carrito);
  mostrarNotificacion("Producto agregado al carrito.");
}

function agregarDesdeDetalle(id) {
  const inputCantidad = document.getElementById("cantidad");
  const cantidad = inputCantidad ? Number(inputCantidad.value) : 1;
  agregarCarrito(id, cantidad);
}

function cambiarCantidad(id, delta) {
  const carrito = obtenerCarrito();
  const item = carrito.find((p) => p.id === id);
  const producto = obtenerProductos().find((p) => p.id === id);
  if (!item || !producto) return;

  item.cantidad += delta;

  if (item.cantidad <= 0) {
    guardarCarrito(carrito.filter((p) => p.id !== id));
  } else if (item.cantidad > producto.stock) {
    mostrarNotificacion("No hay más stock disponible.", "error");
  } else {
    guardarCarrito(carrito);
  }

  renderCarrito();
}

function eliminarCarrito(id) {
  guardarCarrito(obtenerCarrito().filter((p) => p.id !== id));
  renderCarrito();
}

function filaCarrito(item) {
  const puedeRestar = item.cantidad > 1;

  return `
    <article class="item-carrito">
      <img src="${item.imagen}" alt="${item.nombre}">
      <div>
        <h3>${item.nombre}</h3>
        <p>${formatoPrecio(item.precio)} por unidad</p>
        <div class="cantidad">
          <button
            class="btn btn-secundario btn-pequeno"
            data-accion="restar-cantidad"
            data-id="${item.id}"
            ${puedeRestar ? "" : "disabled"}
          >−</button>
          <strong>${item.cantidad}</strong>
          <button class="btn btn-secundario btn-pequeno" data-accion="sumar-cantidad" data-id="${item.id}">+</button>
        </div>
      </div>
      <div class="acciones-item">
        <strong>${formatoPrecio(item.precio * item.cantidad)}</strong><br>
        <button class="btn btn-peligro btn-pequeno" data-accion="eliminar-item" data-id="${item.id}">
          Eliminar
        </button>
      </div>
    </article>
  `;
}

function renderCarrito() {
  const contenedorLista = document.getElementById("lista-carrito");
  if (!contenedorLista) return;

  const contenedorResumen = document.getElementById("resumen-carrito");
  const carrito = obtenerCarrito();

  if (carrito.length === 0) {
    contenedorLista.innerHTML = `
      <div class="vacio">
        <h2>Tu carrito está vacío</h2>
        <p>Agrega productos para comenzar tu pedido.</p>
        <br>
        <a class="btn btn-principal" href="productos.html">Ver productos</a>
      </div>
    `;
    if (contenedorResumen) contenedorResumen.innerHTML = "";
    return;
  }

  contenedorLista.innerHTML = carrito.map(filaCarrito).join("");

  const total = carrito.reduce((suma, item) => suma + item.precio * item.cantidad, 0);

  if (contenedorResumen) {
    contenedorResumen.innerHTML = `
      <h2>Resumen del pedido</h2>
      <div class="fila-total"><span>Productos</span><strong>${formatoPrecio(total)}</strong></div>
      <div class="fila-total"><span>Despacho</span><strong>Según zona</strong></div>
      <div class="fila-total total"><span>Total</span><strong>${formatoPrecio(total)}</strong></div>
      <form id="form-datos-pedido" class="form-pedido" style="margin-top:15px;">
        <h3>Datos de despacho</h3>
        <div class="form-pedido-grid">
          <div class="ancho-completo">
            <label for="direccion-pedido">Dirección de entrega</label>
            <input id="direccion-pedido" name="direccion" required maxlength="150" placeholder="Ej: Av. Libertad 123">
          </div>
          <div>
            <label for="comuna-pedido">Comuna</label>
            <select id="comuna-pedido" name="comuna" required>
              <option value="">Seleccione</option>
              <option>Chillán</option><option>Chillán Viejo</option><option>Bulnes</option>
              <option>Quillón</option><option>El Carmen</option><option>Pinto</option><option>San Ignacio</option>
            </select>
          </div>
          <div>
            <label for="metodo-pago">Método de pago</label>
            <select id="metodo-pago" name="metodoPago" required>
              <option value="Efectivo">Efectivo</option>
              <option value="Transferencia">Transferencia</option>
              <option value="Tarjeta">Tarjeta</option>
            </select>
          </div>
        </div>
        <button class="btn btn-principal" style="width:100%; margin-top:15px;" type="submit">
          Confirmar pedido sin llamada
        </button>
      </form>
    `;
  }
}

/**
 * Confirma el pedido de forma asíncrona: simula que se está
 * consultando disponibilidad con el servidor antes de vaciar el
 * carrito. Usa async/await + try/catch, tal como recomienda la
 * guía para el código asíncrono.
 */

/* ------------------------------------------------------------
   7.1 SISTEMA DE PEDIDOS Y SEGUIMIENTO
   Los pedidos se comparten entre pestañas mediante localStorage
   + evento storage y BroadcastChannel cuando está disponible.
   ------------------------------------------------------------ */

const ESTADOS_PEDIDO = [
  "RECIBIDO",
  "CONFIRMADO",
  "EN_PREPARACION",
  "ASIGNADO",
  "EN_CAMINO",
  "ENTREGADO"
];

const ETIQUETAS_ESTADO = {
  RECIBIDO: "Pedido recibido",
  CONFIRMADO: "Pedido confirmado",
  EN_PREPARACION: "En preparación",
  ASIGNADO: "Repartidor asignado",
  EN_CAMINO: "En camino",
  ENTREGADO: "Entregado",
  CANCELADO: "Cancelado"
};

function obtenerPedidos() {
  const guardados = localStorage.getItem("pedidosGas");
  return guardados ? JSON.parse(guardados) : [];
}

function guardarPedidos(pedidos) {
  localStorage.setItem("pedidosGas", JSON.stringify(pedidos));
  try {
    if (typeof BroadcastChannel !== "undefined") {
      const canal = new BroadcastChannel("gas-volcan-pedidos");
      canal.postMessage({ tipo: "pedidos-actualizados" });
      canal.close();
    }
  } catch (error) {
    console.warn("No se pudo emitir actualización en tiempo real:", error);
  }
}

function emitirActualizacionPedidos() {
  window.dispatchEvent(new Event("pedidos-actualizados"));
}

async function sincronizarPedidosServidor() {
  try {
    const respuesta = await fetch("/api/pedidos", { cache: "no-store" });
    if (!respuesta.ok) return;
    const pedidosServidor = await respuesta.json();
    const locales = obtenerPedidos();
    const porId = new Map(locales.map((pedido) => [pedido.id, pedido]));
    pedidosServidor.forEach((pedido) => porId.set(pedido.id, pedido));
    const combinados = Array.from(porId.values()).sort((a, b) =>
      new Date(b.creadoEn) - new Date(a.creadoEn)
    );
    if (JSON.stringify(combinados) !== JSON.stringify(locales)) {
      localStorage.setItem("pedidosGas", JSON.stringify(combinados));
      emitirActualizacionPedidos();
    }
  } catch (error) {
    console.warn("Servidor de pedidos no disponible; se mantiene localStorage.");
  }

  try {
    const respuestaPagos = await fetch("/api/pagos", { cache: "no-store" });
    if (respuestaPagos.ok) {
      const pagosServidor = await respuestaPagos.json();
      if (pagosServidor.length) {
        localStorage.setItem("pagosGas", JSON.stringify(pagosServidor));
        emitirActualizacionPedidos();
      }
    }
  } catch (error) {
    console.warn("Servidor de pagos no disponible; se mantiene localStorage.");
  }
}

function enviarPedidoAlServidor(pedido) {
  fetch("/api/pedidos", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(pedido)
  }).catch(() => {});
}

function enviarActualizacionAlServidor(pedido) {
  fetch(`/api/pedidos/${encodeURIComponent(pedido.id)}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(pedido)
  }).catch(() => {});
}

function enviarPagoAlServidor(pago) {
  fetch("/api/pagos", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(pago)
  }).catch(() => {});
}

window.addEventListener("storage", (evento) => {
  if (evento.key === "pedidosGas" || evento.key === "pagosGas" || evento.key === "productosGas") {
    emitirActualizacionPedidos();
  }
});

if (typeof BroadcastChannel !== "undefined") {
  try {
    const canalPedidos = new BroadcastChannel("gas-volcan-pedidos");
    canalPedidos.onmessage = () => emitirActualizacionPedidos();
  } catch (error) {
    console.warn("BroadcastChannel no disponible:", error);
  }
}

function obtenerPagos() {
  const guardados = localStorage.getItem("pagosGas");
  return guardados ? JSON.parse(guardados) : [];
}

function guardarPagos(pagos) {
  localStorage.setItem("pagosGas", JSON.stringify(pagos));
}

function usuarioActivoCorreo() {
  return localStorage.getItem("usuarioActivo") || "cliente@demo.com";
}

function numeroPedido() {
  return "GV-" + Date.now().toString().slice(-8);
}

function obtenerPedidoPorId(id) {
  return obtenerPedidos().find((pedido) => pedido.id === id);
}

function registrarPedidoDesdeCarrito() {
  const carrito = obtenerCarrito();
  if (!carrito.length) return null;

  const cliente = usuarioActivoCorreo();
  const nombre = localStorage.getItem("nombreUsuarioActivo") || "Cliente";
  const direccion = localStorage.getItem("direccionEntregaGas") || "Dirección pendiente de confirmar";
  const comuna = localStorage.getItem("comunaEntregaGas") || "Chillán";
  const metodoPago = localStorage.getItem("metodoPagoGas") || "Efectivo";

  const productos = obtenerProductos();
  const items = carrito.map((item) => {
    const producto = productos.find((p) => p.id === item.id);
    return {
      id: item.id,
      nombre: item.nombre,
      cantidad: item.cantidad,
      precio: item.precio,
      subtotal: item.precio * item.cantidad
    };
  });

  const total = items.reduce((suma, item) => suma + item.subtotal, 0);
  const id = numeroPedido();

  const pedido = {
    id,
    cliente,
    nombreCliente: nombre,
    direccion,
    comuna,
    metodoPago,
    items,
    total,
    estado: "RECIBIDO",
    repartidor: null,
    creadoEn: new Date().toISOString(),
    actualizadoEn: new Date().toISOString(),
    historial: [
      { estado: "RECIBIDO", fecha: new Date().toISOString(), usuario: cliente }
    ]
  };

  const stockActualizado = productos.map((producto) => {
    const item = carrito.find((i) => i.id === producto.id);
    if (!item) return producto;
    return { ...producto, stock: Math.max(0, producto.stock - item.cantidad) };
  });

  guardarProductos(stockActualizado);
  const pedidos = obtenerPedidos();
  pedidos.unshift(pedido);
  guardarPedidos(pedidos);
  enviarPedidoAlServidor(pedido);
  localStorage.removeItem("carritoGas");
  localStorage.setItem("ultimoPedidoGas", id);

  return pedido;
}

function cambiarEstadoPedido(id, nuevoEstado, usuario = "Sistema", repartidor = null) {
  const pedidos = obtenerPedidos();
  const pedido = pedidos.find((item) => item.id === id);
  if (!pedido) return null;

  pedido.estado = nuevoEstado;
  pedido.actualizadoEn = new Date().toISOString();

  if (repartidor !== null) pedido.repartidor = repartidor;

  pedido.historial = pedido.historial || [];
  pedido.historial.push({
    estado: nuevoEstado,
    fecha: pedido.actualizadoEn,
    usuario
  });

  guardarPedidos(pedidos);
  enviarActualizacionAlServidor(pedido);

  if (nuevoEstado === "ENTREGADO") {
    registrarPagoAutomatico(pedido, usuario);
  }

  emitirActualizacionPedidos();
  return pedido;
}

function registrarPagoAutomatico(pedido, usuario) {
  const pagos = obtenerPagos();
  const yaExiste = pagos.some((pago) => pago.pedidoId === pedido.id);
  if (yaExiste) return;

  pagos.push({
    id: "PAG-" + pedido.id,
    pedidoId: pedido.id,
    monto: pedido.total,
    metodo: pedido.metodoPago || "Efectivo",
    estado: "PAGADO",
    fecha: new Date().toISOString(),
    confirmadoAutomaticamente: true,
    confirmadoPor: usuario
  });
  guardarPagos(pagos);
  enviarPagoAlServidor(pagos[pagos.length - 1]);
}

function formatoFechaPedido(fecha) {
  return new Date(fecha).toLocaleString("es-CL", {
    dateStyle: "short",
    timeStyle: "short"
  });
}

function renderPasosPedido(pedido) {
  const estados = ESTADOS_PEDIDO;
  const indice = estados.indexOf(pedido.estado);
  return `
    <div class="pasos-pedido">
      ${estados.map((estado, i) => `
        <div class="paso-pedido ${i <= indice ? "activo" : ""}">
          <div class="circulo">${i < indice || estado === pedido.estado ? "✓" : i + 1}</div>
          <span>${ETIQUETAS_ESTADO[estado]}</span>
        </div>
      `).join("")}
    </div>
  `;
}

function renderPedidoCliente(pedido) {
  const contenedor = document.getElementById("seguimiento-pedido");
  if (!contenedor) return;

  if (!pedido) {
    contenedor.innerHTML = `
      <div class="vacio">
        <h2>No hay pedido para mostrar</h2>
        <p>Realiza un pedido desde el catálogo y aquí podrás seguirlo en tiempo real.</p>
        <a class="btn btn-principal" href="productos.html">Ver productos</a>
      </div>`;
    return;
  }

  const pago = obtenerPagos().find((item) => item.pedidoId === pedido.id);
  const estadoClase = pedido.estado === "EN_CAMINO" ? "camino" :
    pedido.estado === "ENTREGADO" ? "entregado" :
    pedido.estado === "CANCELADO" ? "cancelado" : "";

  contenedor.innerHTML = `
    <div class="alerta-tiempo-real">
      🔄 <strong>Seguimiento en tiempo real activo.</strong>
      Esta pantalla se actualiza automáticamente cuando la operadora o el repartidor cambia el estado.
    </div>
    <article class="pedido-card">
      <div class="pedido-cabecera">
        <div>
          <h2>Pedido ${pedido.id}</h2>
          <small>Última actualización: ${formatoFechaPedido(pedido.actualizadoEn)}</small>
        </div>
        <span class="badge-estado ${estadoClase}">${ETIQUETAS_ESTADO[pedido.estado] || pedido.estado}</span>
      </div>
      ${pedido.estado !== "CANCELADO" ? renderPasosPedido(pedido) : ""}
      <div class="pedido-datos">
        <div><strong>Cliente</strong><br>${pedido.nombreCliente}</div>
        <div><strong>Dirección</strong><br>${pedido.direccion}, ${pedido.comuna}</div>
        <div><strong>Total</strong><br>${formatoPrecio(pedido.total)}</div>
        <div><strong>Repartidor</strong><br>${pedido.repartidor || "Aún no asignado"}</div>
        <div><strong>Pago</strong><br>${pago ? "PAGADO automáticamente" : "Pendiente hasta la entrega"}</div>
        <div><strong>Método</strong><br>${pedido.metodoPago || "Efectivo"}</div>
      </div>
      <h3>Productos</h3>
      ${pedido.items.map((item) => `<p>${item.cantidad} × ${item.nombre} — <strong>${formatoPrecio(item.subtotal)}</strong></p>`).join("")}
      <h3>Historial</h3>
      ${(pedido.historial || []).slice().reverse().map((evento) => `
        <div class="timeline-evento">
          <strong>${ETIQUETAS_ESTADO[evento.estado] || evento.estado}</strong>
          <small> — ${formatoFechaPedido(evento.fecha)} por ${evento.usuario}</small>
        </div>
      `).join("")}
    </article>
  `;
}

function renderSeguimientoCliente() {
  const contenedor = document.getElementById("seguimiento-pedido");
  if (!contenedor) return;

  const id = new URLSearchParams(location.search).get("id") || localStorage.getItem("ultimoPedidoGas");
  const pedido = id ? obtenerPedidoPorId(id) : null;
  renderPedidoCliente(pedido);
}

function renderAdminPedidos() {
  const cuerpo = document.getElementById("lista-pedidos-admin");
  if (!cuerpo) return;

  const filtro = document.getElementById("filtro-estado-pedido")?.value || "TODOS";
  const pedidos = obtenerPedidos().filter((pedido) => filtro === "TODOS" || pedido.estado === filtro);

  if (!pedidos.length) {
    cuerpo.innerHTML = `<div class="vacio"><h2>No hay pedidos</h2><p>Los pedidos creados por clientes aparecerán aquí automáticamente.</p></div>`;
    return;
  }

  cuerpo.innerHTML = pedidos.map((pedido) => `
    <article class="pedido-card">
      <div class="pedido-cabecera">
        <div>
          <h2>${pedido.id}</h2>
          <small>${formatoFechaPedido(pedido.creadoEn)} · ${pedido.nombreCliente} · ${pedido.cliente}</small>
        </div>
        <span class="badge-estado">${ETIQUETAS_ESTADO[pedido.estado] || pedido.estado}</span>
      </div>
      <div class="pedido-datos">
        <div><strong>Dirección</strong><br>${pedido.direccion}, ${pedido.comuna}</div>
        <div><strong>Total</strong><br>${formatoPrecio(pedido.total)}</div>
        <div><strong>Repartidor</strong><br>${pedido.repartidor || "Sin asignar"}</div>
      </div>
      <p>${pedido.items.map((i) => `${i.cantidad} × ${i.nombre}`).join(" · ")}</p>
      <div class="pedido-acciones">
        ${pedido.estado === "RECIBIDO" ? `<button class="btn btn-principal btn-pequeno" data-accion="estado-pedido" data-id="${pedido.id}" data-estado="CONFIRMADO">Confirmar pedido</button>` : ""}
        ${pedido.estado === "CONFIRMADO" ? `<button class="btn btn-principal btn-pequeno" data-accion="estado-pedido" data-id="${pedido.id}" data-estado="EN_PREPARACION">Pasar a preparación</button>` : ""}
        ${pedido.estado === "EN_PREPARACION" ? `<button class="btn btn-principal btn-pequeno" data-accion="asignar-repartidor" data-id="${pedido.id}">Asignar repartidor</button>` : ""}
        ${pedido.estado === "ASIGNADO" ? `<button class="btn btn-secundario btn-pequeno" data-accion="estado-pedido" data-id="${pedido.id}" data-estado="EN_CAMINO">Marcar salida</button>` : ""}
        <a class="btn btn-secundario btn-pequeno" href="../seguimiento.html?id=${pedido.id}" target="_blank">Ver seguimiento</a>
      </div>
    </article>
  `).join("");
}

function renderRepartidorPedidos() {
  const cuerpo = document.getElementById("lista-entregas-repartidor");
  if (!cuerpo) return;

  const pedidos = obtenerPedidos().filter((pedido) =>
    pedido.repartidor === "Repartidor Demo" &&
    ["ASIGNADO", "EN_CAMINO"].includes(pedido.estado)
  );

  if (!pedidos.length) {
    cuerpo.innerHTML = `<div class="vacio"><h2>No tienes entregas pendientes</h2><p>Las entregas asignadas por la operadora aparecerán aquí.</p></div>`;
    return;
  }

  cuerpo.innerHTML = pedidos.map((pedido) => `
    <article class="pedido-card">
      <div class="pedido-cabecera">
        <div>
          <h2>${pedido.id}</h2>
          <small>${pedido.nombreCliente} · ${pedido.comuna}</small>
        </div>
        <span class="badge-estado ${pedido.estado === "EN_CAMINO" ? "camino" : ""}">
          ${ETIQUETAS_ESTADO[pedido.estado]}
        </span>
      </div>
      <div class="pedido-datos">
        <div><strong>Dirección</strong><br>${pedido.direccion}, ${pedido.comuna}</div>
        <div><strong>Total</strong><br>${formatoPrecio(pedido.total)}</div>
        <div><strong>Pago</strong><br>Se registra al confirmar entrega</div>
      </div>
      <p>${pedido.items.map((i) => `${i.cantidad} × ${i.nombre}`).join(" · ")}</p>
      <div class="pedido-acciones">
        ${pedido.estado === "ASIGNADO" ? `<button class="btn btn-principal" data-accion="estado-pedido" data-id="${pedido.id}" data-estado="EN_CAMINO">🚚 Iniciar entrega</button>` : ""}
        ${pedido.estado === "EN_CAMINO" ? `<button class="btn btn-principal" data-accion="confirmar-entrega" data-id="${pedido.id}">✅ Confirmar entrega y registrar pago</button>` : ""}
      </div>
    </article>
  `).join("");
}

function asignarRepartidor(id) {
  cambiarEstadoPedido(id, "ASIGNADO", "Operadora Demo", "Repartidor Demo");
  mostrarNotificacion("Pedido asignado al Repartidor Demo.");
  renderAdminPedidos();
  renderRepartidorPedidos();
}

function confirmarEntrega(id) {
  const pedido = cambiarEstadoPedido(id, "ENTREGADO", "Repartidor Demo");
  if (pedido) {
    mostrarNotificacion(`Entrega ${id} confirmada. Pago registrado automáticamente.`);
    renderRepartidorPedidos();
    renderAdminPedidos();
  }
}

function configurarFormularioPedido() {
  const formulario = document.getElementById("form-datos-pedido");
  if (!formulario) return;

  const direccionGuardada = localStorage.getItem("direccionEntregaGas");
  const comunaGuardada = localStorage.getItem("comunaEntregaGas");
  if (direccionGuardada) formulario.direccion.value = direccionGuardada;
  if (comunaGuardada) formulario.comuna.value = comunaGuardada;

  formulario.addEventListener("submit", (evento) => {
    evento.preventDefault();

    const carrito = obtenerCarrito();
    if (!carrito.length) {
      mostrarNotificacion("El carrito está vacío.", "error");
      return;
    }

    localStorage.setItem("direccionEntregaGas", formulario.direccion.value.trim());
    localStorage.setItem("comunaEntregaGas", formulario.comuna.value);
    localStorage.setItem("metodoPagoGas", formulario.metodoPago.value);

    const pedido = registrarPedidoDesdeCarrito();
    if (!pedido) return;

    mostrarNotificacion(`Pedido ${pedido.id} creado correctamente.`);
    location.href = `seguimiento.html?id=${pedido.id}`;
  });
}

function configurarFiltrosPedidos() {
  const filtro = document.getElementById("filtro-estado-pedido");
  if (filtro) filtro.addEventListener("change", renderAdminPedidos);
}


async function finalizarPedido(boton) {
  if (obtenerCarrito().length === 0) return;

  const textoOriginal = boton.textContent;
  boton.disabled = true;
  boton.textContent = "Preparando pedido...";

  try {
    const pedido = registrarPedidoDesdeCarrito();
    if (!pedido) throw new Error("No se pudo crear el pedido.");

    mostrarNotificacion(`Pedido ${pedido.id} creado. Ahora puedes seguir su estado en tiempo real.`);
    renderCarrito();
    actualizarContador();
    location.href = `seguimiento.html?id=${pedido.id}`;
  } catch (error) {
    console.error("No se pudo confirmar el pedido:", error);
    mostrarNotificacion("Ocurrió un problema al crear el pedido. Intenta nuevamente.", "error");
  } finally {
    boton.disabled = false;
    boton.textContent = textoOriginal;
  }
}


/* ------------------------------------------------------------
   8. VALIDACIÓN FORMULARIOS
   ------------------------------------------------------------ */

const correosPermitidos = /^[^\s@]+@(duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/i;

function validarCorreo(valor) {
  return correosPermitidos.test(valor.trim());
}

/** Valida un RUN chileno (con o sin puntos/guion) usando el dígito verificador. */
function validarRUN(run) {
  const limpio = run.replace(/[^0-9kK]/g, "").toUpperCase();
  if (limpio.length < 2) return false;

  const cuerpo = limpio.slice(0, -1);
  const digitoVerificador = limpio.slice(-1);
  if (!/^\d+$/.test(cuerpo)) return false;

  let suma = 0;
  let multiplicador = 2;
  for (let i = cuerpo.length - 1; i >= 0; i--) {
    suma += Number(cuerpo[i]) * multiplicador;
    multiplicador = multiplicador === 7 ? 2 : multiplicador + 1;
  }

  const resto = 11 - (suma % 11);
  const esperado = resto === 11 ? "0" : resto === 10 ? "K" : String(resto);

  return digitoVerificador === esperado;
}

/**
 * Marca un campo como inválido: le agrega la clase "con-error" a
 * su .grupo-form (classList.add) y crea/actualiza el mensaje de
 * error con createElement + textContent.
 */
function errorCampo(input, mensaje) {
  const grupo = input.closest(".grupo-form");
  if (!grupo) return;

  grupo.classList.add("con-error");
  input.setAttribute("aria-invalid", "true");

  let elementoError = grupo.querySelector(".error");
  if (!elementoError) {
    elementoError = document.createElement("div");
    elementoError.className = "error";
    grupo.append(elementoError);
  }
  elementoError.textContent = mensaje;
}

function limpiarError(input) {
  const grupo = input.closest(".grupo-form");
  if (!grupo) return;

  grupo.classList.remove("con-error");
  input.removeAttribute("aria-invalid");

  const elementoError = grupo.querySelector(".error");
  if (elementoError) elementoError.remove();
}

function configurarFormularioLogin() {
  const formulario = document.getElementById("form-login");
  if (!formulario) return;

  formulario.addEventListener("submit", (evento) => {
    evento.preventDefault();

    const correo = formulario.correo;
    const clave = formulario.clave;
    limpiarError(correo);
    limpiarError(clave);
    let esValido = true;

    if (!correo.value.trim()) {
      errorCampo(correo, "El correo es obligatorio.");
      esValido = false;
    } else if (correo.value.length > 100 || !validarCorreo(correo.value)) {
      errorCampo(correo, "Usa un correo @duoc.cl, @profesor.duoc.cl o @gmail.com.");
      esValido = false;
    }

    if (!clave.value) {
      errorCampo(clave, "La contraseña es obligatoria.");
      esValido = false;
    } else if (clave.value.length < 4 || clave.value.length > 10) {
      errorCampo(clave, "La contraseña debe tener entre 4 y 10 caracteres.");
      esValido = false;
    }

    if (esValido) {
      localStorage.setItem("usuarioActivo", correo.value);

      const rolesDemo = {
        "admin@gmail.com": "Administrador",
        "operadora@duoc.cl": "Operadora / Despachadora",
        "repartidor@gmail.com": "Repartidor"
      };
      const rol = rolesDemo[correo.value.trim().toLowerCase()] || "Cliente";
      localStorage.setItem("rolUsuarioActivo", rol);
      localStorage.setItem("nombreUsuarioActivo",
        rol === "Repartidor" ? "Repartidor Demo" :
        rol === "Operadora / Despachadora" ? "Operadora Demo" :
        rol === "Administrador" ? "Administrador Demo" : correo.value
      );

      mostrarNotificacion("Inicio de sesión correcto.");

      if (rol === "Administrador" || rol === "Operadora / Despachadora") {
        location.href = "admin/index.html";
      } else if (rol === "Repartidor") {
        location.href = "repartidor.html";
      } else {
        location.href = "index.html";
      }
    }
  });
}

function configurarFormularioRegistro() {
  const formulario = document.getElementById("form-registro");
  if (!formulario) return;

  formulario.addEventListener("submit", (evento) => {
    evento.preventDefault();

    const campos = [
      formulario.run,
      formulario.nombre,
      formulario.apellidos,
      formulario.correo,
      formulario.clave,
      formulario.region,
      formulario.comuna
    ];
    campos.forEach(limpiarError);
    let esValido = true;

    if (!validarRUN(formulario.run.value)) {
      errorCampo(formulario.run, "RUN no válido.");
      esValido = false;
    }
    if (!formulario.nombre.value.trim() || formulario.nombre.value.length > 100) {
      errorCampo(formulario.nombre, "Ingresa un nombre válido de máximo 100 caracteres.");
      esValido = false;
    }
    if (!formulario.apellidos.value.trim() || formulario.apellidos.value.length > 100) {
      errorCampo(formulario.apellidos, "Ingresa apellidos válidos de máximo 100 caracteres.");
      esValido = false;
    }
    if (!validarCorreo(formulario.correo.value) || formulario.correo.value.length > 100) {
      errorCampo(formulario.correo, "Correo no permitido.");
      esValido = false;
    }
    if (formulario.clave.value.length < 4 || formulario.clave.value.length > 10) {
      errorCampo(formulario.clave, "La contraseña debe tener entre 4 y 10 caracteres.");
      esValido = false;
    }
    if (!formulario.region.value) {
      errorCampo(formulario.region, "Selecciona una región.");
      esValido = false;
    }
    if (!formulario.comuna.value) {
      errorCampo(formulario.comuna, "Selecciona una comuna.");
      esValido = false;
    }
    if (!formulario.terminos.checked) {
      mostrarNotificacion("Debes aceptar los términos y condiciones para registrarte.", "error");
      esValido = false;
    }

    if (esValido) {
      mostrarNotificacion("Usuario registrado correctamente.");
      formulario.reset();
    }
  });
}

function configurarFormularioContacto() {
  const formulario = document.getElementById("form-contacto");
  if (!formulario) return;

  formulario.addEventListener("submit", (evento) => {
    evento.preventDefault();

    const nombre = formulario.nombre;
    const correo = formulario.correo;
    const comentario = formulario.comentario;
    [nombre, correo, comentario].forEach(limpiarError);
    let esValido = true;

    if (!nombre.value.trim() || nombre.value.length > 100) {
      errorCampo(nombre, "El nombre es obligatorio y máximo 100 caracteres.");
      esValido = false;
    }
    if (!validarCorreo(correo.value) || correo.value.length > 100) {
      errorCampo(correo, "Correo no permitido.");
      esValido = false;
    }
    if (!comentario.value.trim() || comentario.value.length > 500) {
      errorCampo(comentario, "El comentario es obligatorio y máximo 500 caracteres.");
      esValido = false;
    }

    if (esValido) {
      // textContent, no innerHTML: el mensaje se arma acá mismo,
      // pero igual es buena práctica usar textContent con texto plano.
      const mensajeExito = document.getElementById("mensaje-contacto");
      if (mensajeExito) {
        mensajeExito.textContent = "Mensaje enviado correctamente. Gracias por contactarnos.";
      }
      formulario.reset();
    }
  });
}

function configurarFormularioProducto() {
  const formulario = document.getElementById("form-producto");
  if (!formulario) return;

  formulario.addEventListener("submit", (evento) => {
    evento.preventDefault();

    const datos = new FormData(formulario);
    const producto = {
      id: datos.get("codigo").trim(),
      categoria: datos.get("categoria"),
      nombre: datos.get("nombre").trim(),
      descripcion: datos.get("descripcion").trim(),
      precio: Number(datos.get("precio")),
      precioComercial: Number(datos.get("precioComercial") || datos.get("precio")),
      stock: Number(datos.get("stock")),
      imagen: "img/producto.svg"
    };

    const productos = obtenerProductos();
    const indiceExistente = productos.findIndex((p) => p.id === producto.id);

    if (indiceExistente >= 0) {
      productos[indiceExistente] = producto;
    } else {
      productos.push(producto);
    }

    guardarProductos(productos);
    mostrarNotificacion("Producto guardado correctamente.");
    location.href = "productos.html";
  });
}

function configurarFormularioUsuario() {
  const formulario = document.getElementById("form-usuario");
  if (!formulario) return;

  formulario.addEventListener("submit", (evento) => {
    evento.preventDefault();

    const run = formulario.run;
    const nombre = formulario.nombre;
    const correo = formulario.correo;
    [run, nombre, correo].forEach(limpiarError);
    let esValido = true;

    if (!validarRUN(run.value)) {
      errorCampo(run, "RUN no válido.");
      esValido = false;
    }
    if (!nombre.value.trim() || nombre.value.length > 100) {
      errorCampo(nombre, "Nombre obligatorio y máximo 100 caracteres.");
      esValido = false;
    }
    if (!validarCorreo(correo.value) || correo.value.length > 100) {
      errorCampo(correo, "Correo no permitido.");
      esValido = false;
    }

    if (esValido) {
      const usuarios = obtenerUsuarios();
      usuarios.push({
        run: run.value,
        nombre: nombre.value,
        correo: correo.value,
        rol: formulario.rol.value,
        activo: true
      });
      guardarUsuarios(usuarios);
      mostrarNotificacion("Usuario guardado correctamente.");
      location.href = "usuarios.html";
    }
  });
}

function configurarFormularios() {
  configurarFormularioLogin();
  configurarFormularioRegistro();
  configurarFormularioContacto();
  configurarFormularioProducto();
  configurarFormularioUsuario();
}


/* ------------------------------------------------------------
   9. REGIÓN / COMUNA DEPENDIENTES
   ------------------------------------------------------------ */

const comunasPorRegion = {
  nuble: ["Chillán", "Chillán Viejo", "Bulnes", "Quillón", "El Carmen", "Pinto", "San Ignacio"],
  biobio: ["Los Ángeles", "Concepción"],
  araucania: ["Temuco"]
};

function actualizarComunas() {
  const selectorRegion = document.getElementById("region");
  const selectorComuna = document.getElementById("comuna");
  if (!selectorRegion || !selectorComuna) return;

  const comunas = comunasPorRegion[selectorRegion.value] || [];
  const opciones = comunas.map((comuna) => `<option>${comuna}</option>`).join("");
  selectorComuna.innerHTML = '<option value="">Seleccione una comuna</option>' + opciones;
}

function activarSelectorRegion() {
  const selectorRegion = document.getElementById("region");
  if (selectorRegion) selectorRegion.addEventListener("change", actualizarComunas);
}


/* ------------------------------------------------------------
   10. PANEL ADMINISTRADOR
   ------------------------------------------------------------ */

function filaProductoAdmin(producto) {
  const stockCritico = producto.stock <= 10;

  return `
    <tr>
      <td>${producto.id}</td>
      <td>${producto.nombre}</td>
      <td>${producto.categoria}</td>
      <td>${formatoPrecio(producto.precio)}</td>
      <td>${producto.stock}</td>
      <td><span class="estado ${stockCritico ? "critico" : ""}">${stockCritico ? "Stock crítico" : "Disponible"}</span></td>
      <td>
        <a class="btn btn-secundario btn-pequeno" href="producto.html?id=${producto.id}">Editar</a>
        <button class="btn btn-peligro btn-pequeno" data-accion="eliminar-producto" data-id="${producto.id}">
          Eliminar
        </button>
      </td>
    </tr>
  `;
}

function renderAdminProductos() {
  const cuerpoTabla = document.getElementById("tabla-productos");
  if (!cuerpoTabla) return;

  cuerpoTabla.innerHTML = obtenerProductos().map(filaProductoAdmin).join("");
}

function usuariosDeEjemplo() {
  return [
    { run: "12.345.678-5", nombre: "Administrador Demo", correo: "admin@gmail.com", rol: "Administrador", activo: true },
    { run: "11.111.111-1", nombre: "Operadora Demo", correo: "operadora@duoc.cl", rol: "Operadora / Despachadora", activo: true },
    { run: "10.222.333-4", nombre: "Repartidor Demo", correo: "repartidor@gmail.com", rol: "Repartidor", activo: true }
  ];
}

function renderAdminUsuarios() {
  const cuerpoTabla = document.getElementById("tabla-usuarios");
  if (!cuerpoTabla) return;

  const usuarios = obtenerUsuarios().length ? obtenerUsuarios() : usuariosDeEjemplo();

  cuerpoTabla.innerHTML = usuarios
    .map(
      (usuario) => `
        <tr>
          <td>${usuario.run}</td>
          <td>${usuario.nombre}</td>
          <td>${usuario.correo}</td>
          <td>${usuario.rol}</td>
          <td>${usuario.activo ? "Activo" : "Inactivo"}</td>
        </tr>
      `
    )
    .join("");
}

function renderDashboard() {
  const totalProductos = document.getElementById("total-productos");
  const stockCritico = document.getElementById("stock-critico");
  const totalCarrito = document.getElementById("total-carrito");
  const totalPedidos = document.getElementById("total-pedidos");
  const totalPagos = document.getElementById("total-pagos");

  const productos = obtenerProductos();

  if (totalProductos) totalProductos.textContent = productos.length;
  if (stockCritico) stockCritico.textContent = productos.filter((p) => p.stock <= 10).length;
  if (totalCarrito) totalCarrito.textContent = obtenerCarrito().reduce((suma, p) => suma + p.cantidad, 0);
  if (totalPedidos) totalPedidos.textContent = obtenerPedidos().length;
  if (totalPagos) totalPagos.textContent = obtenerPagos().length;
}

/** Si la URL trae ?id=..., precarga ese producto en el formulario de edición. */
function cargarProductoAdmin() {
  const formulario = document.getElementById("form-producto");
  if (!formulario) return;

  const id = new URLSearchParams(location.search).get("id");
  if (!id) return;

  const producto = obtenerProductos().find((p) => p.id === id);
  if (!producto) return;

  formulario.codigo.value = producto.id;
  formulario.nombre.value = producto.nombre;
  formulario.categoria.value = producto.categoria;
  formulario.precio.value = producto.precio;
  formulario.precioComercial.value = producto.precioComercial;
  formulario.stock.value = producto.stock;
  formulario.descripcion.value = producto.descripcion;
}

function eliminarProductoAdmin(id) {
  const productos = obtenerProductos().filter((p) => p.id !== id);
  guardarProductos(productos);
  renderAdminProductos();
  renderDashboard();
  mostrarNotificacion("Producto eliminado.");
}


/* ------------------------------------------------------------
   11. DELEGACIÓN DE EVENTOS
   En vez de usar onclick="..." dentro del HTML generado (mala
   práctica según la guía), todos los botones dinámicos llevan un
   atributo data-accion. Un único listener escucha los clics de
   toda la página y decide qué hacer según event.target.
   ------------------------------------------------------------ */

function inicializarEventosGlobales() {
  document.addEventListener("click", (evento) => {
    const botón = evento.target.closest("[data-accion]");
    if (!botón) return;

    const id = botón.dataset.id;

    switch (botón.dataset.accion) {
      case "agregar-carrito":
        agregarCarrito(id);
        break;

      case "agregar-desde-detalle":
        agregarDesdeDetalle(id);
        break;

      case "restar-cantidad":
        cambiarCantidad(id, -1);
        break;

      case "sumar-cantidad":
        cambiarCantidad(id, 1);
        break;

      case "eliminar-item":
        eliminarCarrito(id);
        break;

      case "finalizar-pedido":
        finalizarPedido(botón);
        break;

      case "estado-pedido":
        cambiarEstadoPedido(id, botón.dataset.estado, localStorage.getItem("nombreUsuarioActivo") || "Operadora Demo");
        mostrarNotificacion(`Pedido ${id}: ${ETIQUETAS_ESTADO[botón.dataset.estado]}.`);
        renderAdminPedidos();
        renderRepartidorPedidos();
        renderSeguimientoCliente();
        break;

      case "asignar-repartidor":
        asignarRepartidor(id);
        break;

      case "confirmar-entrega":
        confirmarEntrega(id);
        break;

      case "eliminar-producto":
        eliminarProductoAdmin(id);
        break;

      default:
        break;
    }
  });
}


/* ------------------------------------------------------------
   12. CARGA ASÍNCRONA DEL CATÁLOGO (fetch + Promise)
   Intenta traer el catálogo desde data/productos.json. Si el
   archivo no existe o falla la red, sencillamente seguimos
   usando productosIniciales (ya cargado por defecto), así que
   el sitio nunca se rompe por un problema de conexión.
   ------------------------------------------------------------ */

function cargarCatalogoDesdeServidor() {
  const yaHayCatalogoGuardado = localStorage.getItem("productosGas");
  const versionGuardada = localStorage.getItem("catalogoVersion");
  const catalogoDesactualizado = versionGuardada !== CATALOGO_VERSION;

  // Si ya hay catálogo guardado Y sigue en la misma versión, lo respetamos
  // (para no pisar cambios hechos desde el admin). Si la versión cambió,
  // volvemos a pedirlo al servidor aunque ya hubiera algo guardado.
  if (yaHayCatalogoGuardado && !catalogoDesactualizado) return;

  fetch("data/productos.json")
    .then((respuesta) => {
      if (!respuesta.ok) throw new Error("No se pudo leer el catálogo del servidor.");
      return respuesta.json();
    })
    .then((productos) => {
      guardarProductos(productos);
      localStorage.setItem("catalogoVersion", CATALOGO_VERSION);
      // Se re-dibuja todo lo que ya se haya pintado con los datos por defecto
      renderDestacados();
      renderProductos();
      renderDetalle();
      renderAdminProductos();
      renderDashboard();
    })
    .catch((error) => {
      console.warn("Usando catálogo local de respaldo:", error.message);
    });
}


/* ------------------------------------------------------------
   13. ARRANQUE DE LA APLICACIÓN
   ------------------------------------------------------------ */

document.addEventListener("DOMContentLoaded", () => {
  activarMenu();
  actualizarContador();

  renderDestacados();
  renderProductos();
  renderDetalle();
  renderCarrito();

  renderAdminProductos();
  renderAdminUsuarios();
  renderDashboard();
  cargarProductoAdmin();

  configurarFormularios();
  configurarFormularioPedido();
  configurarFiltrosPedidos();
  activarSelectorRegion();
  inicializarEventosGlobales();

  renderSeguimientoCliente();
  renderAdminPedidos();
  renderRepartidorPedidos();

  window.addEventListener("pedidos-actualizados", () => {
    renderSeguimientoCliente();
    renderAdminPedidos();
    renderRepartidorPedidos();
    renderDashboard();
  });

  cargarCatalogoDesdeServidor();
  sincronizarPedidosServidor();
  setInterval(sincronizarPedidosServidor, 2000);
});
