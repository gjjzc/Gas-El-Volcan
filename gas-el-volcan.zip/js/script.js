/* ============================================================
   GAS EL VOLCÁN — script.js
   ------------------------------------------------------------
   Índice de este archivo (para ubicarse rápido):
     1. Datos iniciales del catálogo (respaldo local)
     2. Acceso a datos guardados (localStorage)
     3. Utilidades generales (formato de precio, typeof, etc.)
     4. Sistema de notificaciones (reemplaza a alert())
     5. Menú de navegación (mobile)
     6. Render de productos (listado, destacados, detalle)
     7. Carrito de compras
     8. Validación de formularios (login, registro, contacto...)
     9. Región / comuna dependientes
    10. Panel administrador (productos y usuarios)
    11. Delegación de eventos (reemplaza a los onclick="")
    12. Carga asíncrona del catálogo (fetch + async/await)
    13. Arranque de la aplicación (DOMContentLoaded)

   Dónde se usa cada tema de la guía HTML/CSS/JS:
     - const / let, arrow functions       -> en todo el archivo
     - array: map/filter/reduce/find/push -> sección 6, 7 y 10
     - DOM: querySelector, classList,
       createElement, append, textContent -> secciones 4, 8, 11
     - Eventos: addEventListener,
       event.target, preventDefault       -> secciones 5, 8, 11
     - Promise, async/await, fetch, try/catch -> secciones 7 y 12
     - typeof                             -> sección 3 (esNumeroValido)
   ============================================================ */


/* ------------------------------------------------------------
   1. DATOS INICIALES DEL CATÁLOGO
   Este arreglo es el respaldo que se usa si todavía no se pudo
   cargar el catálogo desde data/productos.json (ver sección 12).
   ------------------------------------------------------------ */

/* Cada vez que cambies data/productos.json (nuevos productos, precios,
   o —como acá— rutas de imágenes corregidas), sube este número. Así el
   navegador del cliente sabe que su copia en localStorage quedó vieja
   y vuelve a pedir el catálogo al servidor en vez de seguir usando la
   versión cacheada. */
const CATALOGO_VERSION = "2";

const productosIniciales = [
  { id: "CL001", categoria: "Cilindros de Gas", nombre: "Cilindro GLP 5 kg", descripcion: "Cilindro de gas licuado de petróleo 5 kg. Para uso residencial (cocina, calefacción pequeña).", precio: 6500, precioComercial: 6000, stock: 80, imagen: "img/cilindro5K.webp" },
  { id: "CL002", categoria: "Cilindros de Gas", nombre: "Cilindro GLP 11 kg", descripcion: "Cilindro estándar doméstico. El más utilizado en hogares chilenos. Compatible con reguladores estándar.", precio: 12000, precioComercial: 11000, stock: 200, imagen: "img/cilindro11K.webp" },
  { id: "CL003", categoria: "Cilindros de Gas", nombre: "Cilindro GLP 15 kg", descripcion: "Cilindro de mayor capacidad para hogares de alto consumo o locales pequeños.", precio: 16000, precioComercial: 14500, stock: 90, imagen: "img/cilindro15K.jpg" },
  { id: "CL004", categoria: "Cilindros de Gas", nombre: "Cilindro GLP 45 kg", descripcion: "Cilindro industrial. Uso comercial: restaurantes, talleres y calefacción de locales.", precio: 45000, precioComercial: 40000, stock: 30, imagen: "img/cilindro45K.webp" },
  { id: "RG001", categoria: "Reguladores", nombre: "Regulador doméstico estándar", descripcion: "Regulador de 1 etapa para cilindros 5, 11 y 15 kg. Presión de salida 28 mbar.", precio: 8990, precioComercial: 8200, stock: 45, imagen: "img/reguladorEstandar.webp" },
  { id: "RG002", categoria: "Reguladores", nombre: "Regulador de alta presión", descripcion: "Regulador para cocinas industriales o equipos de mayor consumo. Presión regulable.", precio: 18990, precioComercial: 17000, stock: 12, imagen: "img/reguladorGasAPresion.webp" },
  { id: "RG003", categoria: "Reguladores", nombre: "Regulador dual (2 salidas)", descripcion: "Permite conectar dos artefactos simultáneamente al mismo cilindro.", precio: 14990, precioComercial: 13500, stock: 18, imagen: "img/regulador2Salidas.webp" },
  { id: "MG001", categoria: "Mangueras y Conexiones", nombre: "Manguera gas 1.5 m", descripcion: "Manguera flexible homologada. Diámetro interior 9mm. Compatible con reguladores estándar.", precio: 3990, precioComercial: 3500, stock: 80, imagen: "img/mangera1.5m.webp" },
  { id: "MG002", categoria: "Mangueras y Conexiones", nombre: "Manguera gas 3 m", descripcion: "Manguera larga para instalaciones donde el artefacto está alejado del cilindro.", precio: 6990, precioComercial: 6200, stock: 50, imagen: "img/mangera3m.webp" },
  { id: "MG003", categoria: "Mangueras y Conexiones", nombre: "Abrazadera metálica", descripcion: "Abrazadera de acero para asegurar la conexión manguera-regulador y manguera-artefacto.", precio: 990, precioComercial: 800, stock: 200, imagen: "img/abrazadera-metalica.jpg" },
  { id: "MG004", categoria: "Mangueras y Conexiones", nombre: "Kit conexión completo", descripcion: "Regulador + manguera 1.5 m + abrazaderas. Todo lo necesario para instalar un cilindro nuevo.", precio: 12990, precioComercial: 11500, stock: 25, imagen: "img/kitCompleto.webp" },
  { id: "AC001", categoria: "Accesorios", nombre: "Carro porta cilindro 11/15 kg", descripcion: "Carro metálico con ruedas para transportar cilindros dentro del hogar con seguridad.", precio: 12990, precioComercial: 11000, stock: 20, imagen: "img/carroPortaGas.webp" },
  { id: "AC002", categoria: "Accesorios", nombre: "Tapa protectora para válvula", descripcion: "Tapa de plástico ABS para proteger la válvula del cilindro durante el transporte.", precio: 1490, precioComercial: 1200, stock: 60, imagen: "img/tapaValvula.jpg" },
  { id: "AC003", categoria: "Accesorios", nombre: "Detector de gas a batería", descripcion: "Sensor electroquímico. Alarma sonora y visual ante fuga de gas GLP o metano.", precio: 19990, precioComercial: 17000, stock: 8, imagen: "img/detectorDeGas.webp" }
];


/* ------------------------------------------------------------
   2. ACCESO A DATOS GUARDADOS (localStorage)
   ------------------------------------------------------------ */

function obtenerProductos() {
  const guardados = localStorage.getItem("productosGas");
  return guardados ? JSON.parse(guardados) : productosIniciales;
}

function guardarProductos(productos) {
  localStorage.setItem("productosGas", JSON.stringify(productos));
}

function obtenerCarrito() {
  const guardado = localStorage.getItem("carritoGas");
  return guardado ? JSON.parse(guardado) : [];
}

function guardarCarrito(carrito) {
  localStorage.setItem("carritoGas", JSON.stringify(carrito));
  actualizarContador();
}

function obtenerUsuarios() {
  const guardado = localStorage.getItem("usuariosGas");
  return guardado ? JSON.parse(guardado) : [];
}

function guardarUsuarios(usuarios) {
  localStorage.setItem("usuariosGas", JSON.stringify(usuarios));
}


/* ------------------------------------------------------------
   3. UTILIDADES GENERALES
   ------------------------------------------------------------ */

/** Da formato de pesos chilenos a un número: 12000 -> "$12.000" */
function formatoPrecio(valor) {
  return "$" + Number(valor).toLocaleString("es-CL");
}

/**
 * Verifica que un valor sea realmente un número utilizable
 * (ni texto, ni vacío, ni NaN). Usa el operador typeof, que es
 * la forma estándar de consultar el tipo de un valor en JS.
 */
function esNumeroValido(valor) {
  const numero = Number(valor);
  return typeof numero === "number" && !Number.isNaN(numero);
}

/** Pausa la ejecución "ms" milisegundos. Devuelve una Promise. */
function esperar(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}


/* ------------------------------------------------------------
   4. SISTEMA DE NOTIFICACIONES (reemplaza a los alert())
   Usa document.createElement(), classList y append() en vez de
   innerHTML, porque el mensaje puede incluir datos que en el
   futuro vengan de un formulario (buena práctica de seguridad).
   ------------------------------------------------------------ */

function obtenerContenedorNotificaciones() {
  let contenedor = document.querySelector(".notificaciones");
  if (!contenedor) {
    contenedor = document.createElement("div");
    contenedor.className = "notificaciones";
    document.body.append(contenedor);
  }
  return contenedor;
}

function mostrarNotificacion(mensaje, tipo = "info") {
  const contenedor = obtenerContenedorNotificaciones();

  const aviso = document.createElement("div");
  aviso.className = "notificacion" + (tipo === "error" ? " error" : "");
  aviso.textContent = mensaje; // textContent: nunca interpreta HTML

  contenedor.append(aviso);

  // Se muestra con una transición y se retira sola después de un rato
  requestAnimationFrame(() => aviso.classList.add("visible"));
  setTimeout(() => {
    aviso.classList.remove("visible");
    setTimeout(() => aviso.remove(), 250);
  }, 2600);
}


/* ------------------------------------------------------------
   5. MENÚ DE NAVEGACIÓN (mobile)
   ------------------------------------------------------------ */

function activarMenu() {
  const boton = document.querySelector(".hamburguesa");
  const menu = document.querySelector(".menu");
  if (!boton || !menu) return;

  boton.addEventListener("click", () => {
    menu.classList.toggle("abierto");
  });
}

function actualizarContador() {
  const totalItems = obtenerCarrito().reduce((suma, item) => suma + item.cantidad, 0);
  document.querySelectorAll(".contador-carrito").forEach((elemento) => {
    elemento.textContent = totalItems;
  });
}


/* ------------------------------------------------------------
   6. RENDER DE PRODUCTOS (listado, destacados y detalle)
   ------------------------------------------------------------ */

/**
 * Genera el HTML de una tarjeta de producto.
 * Se usa innerHTML porque el contenido sale de nuestro propio
 * catálogo (no de un formulario ni de otro usuario), así que no
 * hay riesgo de inyectar HTML no confiable (ver guía, sección 29).
 */
function tarjetaProducto(producto) {
  return `
    <article class="tarjeta">
      <a href="detalle.html?id=${producto.id}">
        <img src="${producto.imagen}" alt="${producto.nombre}">
      </a>
      <div class="contenido">
        <span class="categoria">${producto.categoria}</span>
        <h3>${producto.nombre}</h3>
        <p>${producto.descripcion}</p>
        <div class="precio">${formatoPrecio(producto.precio)}</div>
        <small>Stock disponible: ${producto.stock}</small>
        <div class="acciones-card">
          <a class="btn btn-secundario" href="detalle.html?id=${producto.id}">Ver detalle</a>
          <button class="btn btn-principal" data-accion="agregar-carrito" data-id="${producto.id}">
            Añadir
          </button>
        </div>
      </div>
    </article>
  `;
}

function renderDestacados() {
  const contenedor = document.getElementById("lista-destacados");
  if (!contenedor) return;

  const destacados = obtenerProductos().slice(0, 4);
  contenedor.innerHTML = destacados.map(tarjetaProducto).join("");
}

function renderProductos() {
  const contenedor = document.getElementById("lista-productos");
  if (!contenedor) return;

  const productos = obtenerProductos();
  const selectorCategoria = document.getElementById("filtro-categoria");
  const buscador = document.getElementById("buscar-producto");

  function pintarLista() {
    let lista = productos;

    const categoriaElegida = selectorCategoria ? selectorCategoria.value : "Todas";
    if (categoriaElegida !== "Todas") {
      lista = lista.filter((producto) => producto.categoria === categoriaElegida);
    }

    const textoBusqueda = buscador ? buscador.value.trim().toLowerCase() : "";
    if (textoBusqueda) {
      lista = lista.filter((producto) =>
        producto.nombre.toLowerCase().includes(textoBusqueda) ||
        producto.descripcion.toLowerCase().includes(textoBusqueda)
      );
    }

    contenedor.innerHTML = lista.length
      ? lista.map(tarjetaProducto).join("")
      : '<div class="vacio">No se encontraron productos.</div>';
  }

  if (selectorCategoria) selectorCategoria.addEventListener("change", pintarLista);
  if (buscador) buscador.addEventListener("input", pintarLista);

  pintarLista();
}

function renderDetalle() {
  const contenedor = document.getElementById("detalle-producto");
  if (!contenedor) return;

  const idBuscado = new URLSearchParams(location.search).get("id") || "CL002";
  const productos = obtenerProductos();
  const producto = productos.find((item) => item.id === idBuscado) || productos[0];

  contenedor.innerHTML = `
    <div class="detalle-imagen">
      <img src="${producto.imagen}" alt="${producto.nombre}">
    </div>
    <div>
      <span class="categoria">${producto.categoria}</span>
      <h1>${producto.nombre}</h1>
      <p>${producto.descripcion}</p>
      <div class="precio">${formatoPrecio(producto.precio)}</div>
      <p><strong>Stock:</strong> ${producto.stock} unidades</p>

      <div class="cantidad">
        <label for="cantidad">Cantidad:</label>
        <input id="cantidad" type="number" min="1" max="${producto.stock}" value="1">
      </div>

      <button class="btn btn-principal" data-accion="agregar-desde-detalle" data-id="${producto.id}">
        Añadir al carrito
      </button>
      <a class="btn btn-secundario" href="productos.html">Volver a productos</a>
    </div>
  `;
}


/* ------------------------------------------------------------
   7. CARRITO DE COMPRAS
   ------------------------------------------------------------ */

function agregarCarrito(id, cantidad = 1) {
  const producto = obtenerProductos().find((item) => item.id === id);
  if (!producto) return;

  if (!esNumeroValido(cantidad) || cantidad < 1 || cantidad > producto.stock) {
    mostrarNotificacion("La cantidad solicitada no está disponible.", "error");
    return;
  }

  const carrito = obtenerCarrito();
  const itemExistente = carrito.find((item) => item.id === id);

  if (itemExistente) {
    if (itemExistente.cantidad + cantidad > producto.stock) {
      mostrarNotificacion("No hay suficiente stock para agregar esa cantidad.", "error");
      return;
    }
    itemExistente.cantidad += cantidad;
  } else {
    carrito.push({
      id: producto.id,
      nombre: producto.nombre,
      precio: producto.precio,
      imagen: producto.imagen,
      cantidad
    });
  }

  guardarCarrito(carrito);
  mostrarNotificacion("Producto agregado al carrito.");
}

function agregarDesdeDetalle(id) {
  const inputCantidad = document.getElementById("cantidad");
  const cantidad = inputCantidad ? Number(inputCantidad.value) : 1;
  agregarCarrito(id, cantidad);
}

function cambiarCantidad(id, delta) {
  const carrito = obtenerCarrito();
  const item = carrito.find((p) => p.id === id);
  const producto = obtenerProductos().find((p) => p.id === id);
  if (!item || !producto) return;

  item.cantidad += delta;

  if (item.cantidad <= 0) {
    guardarCarrito(carrito.filter((p) => p.id !== id));
  } else if (item.cantidad > producto.stock) {
    mostrarNotificacion("No hay más stock disponible.", "error");
  } else {
    guardarCarrito(carrito);
  }

  renderCarrito();
}

function eliminarCarrito(id) {
  guardarCarrito(obtenerCarrito().filter((p) => p.id !== id));
  renderCarrito();
}

function filaCarrito(item) {
  const puedeRestar = item.cantidad > 1;

  return `
    <article class="item-carrito">
      <img src="${item.imagen}" alt="${item.nombre}">
      <div>
        <h3>${item.nombre}</h3>
        <p>${formatoPrecio(item.precio)} por unidad</p>
        <div class="cantidad">
          <button
            class="btn btn-secundario btn-pequeno"
            data-accion="restar-cantidad"
            data-id="${item.id}"
            ${puedeRestar ? "" : "disabled"}
          >−</button>
          <strong>${item.cantidad}</strong>
          <button class="btn btn-secundario btn-pequeno" data-accion="sumar-cantidad" data-id="${item.id}">+</button>
        </div>
      </div>
      <div class="acciones-item">
        <strong>${formatoPrecio(item.precio * item.cantidad)}</strong><br>
        <button class="btn btn-peligro btn-pequeno" data-accion="eliminar-item" data-id="${item.id}">
          Eliminar
        </button>
      </div>
    </article>
  `;
}

function renderCarrito() {
  const contenedorLista = document.getElementById("lista-carrito");
  if (!contenedorLista) return;

  const contenedorResumen = document.getElementById("resumen-carrito");
  const carrito = obtenerCarrito();

  if (carrito.length === 0) {
    contenedorLista.innerHTML = `
      <div class="vacio">
        <h2>Tu carrito está vacío</h2>
        <p>Agrega productos para comenzar tu pedido.</p>
        <br>
        <a class="btn btn-principal" href="productos.html">Ver productos</a>
      </div>
    `;
    if (contenedorResumen) contenedorResumen.innerHTML = "";
    return;
  }

  contenedorLista.innerHTML = carrito.map(filaCarrito).join("");

  const total = carrito.reduce((suma, item) => suma + item.precio * item.cantidad, 0);

  if (contenedorResumen) {
    contenedorResumen.innerHTML = `
      <h2>Resumen del pedido</h2>
      <div class="fila-total"><span>Productos</span><strong>${formatoPrecio(total)}</strong></div>
      <div class="fila-total"><span>Despacho</span><strong>Según zona</strong></div>
      <div class="fila-total total"><span>Total</span><strong>${formatoPrecio(total)}</strong></div>
      <button class="btn btn-principal" style="width:100%; margin-top:15px;" data-accion="finalizar-pedido">
        Confirmar pedido
      </button>
    `;
  }
}

/**
 * Confirma el pedido de forma asíncrona: simula que se está
 * consultando disponibilidad con el servidor antes de vaciar el
 * carrito. Usa async/await + try/catch, tal como recomienda la
 * guía para el código asíncrono.
 */
async function finalizarPedido(boton) {
  if (obtenerCarrito().length === 0) return;

  const textoOriginal = boton.textContent;
  boton.disabled = true;
  boton.textContent = "Procesando pedido...";

  try {
    await esperar(700); // simula la espera de una confirmación del servidor
    mostrarNotificacion("Pedido registrado correctamente. Una operadora lo confirmará por teléfono.");
    localStorage.removeItem("carritoGas");
    renderCarrito();
    actualizarContador();
  } catch (error) {
    console.error("No se pudo confirmar el pedido:", error);
    mostrarNotificacion("Ocurrió un problema al confirmar el pedido. Intenta nuevamente.", "error");
  } finally {
    boton.disabled = false;
    boton.textContent = textoOriginal;
  }
}


/* ------------------------------------------------------------
   8. VALIDACIÓN DE FORMULARIOS
   ------------------------------------------------------------ */

const correosPermitidos = /^[^\s@]+@(duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/i;

function validarCorreo(valor) {
  return correosPermitidos.test(valor.trim());
}

/** Valida un RUN chileno (con o sin puntos/guion) usando el dígito verificador. */
function validarRUN(run) {
  const limpio = run.replace(/[^0-9kK]/g, "").toUpperCase();
  if (limpio.length < 2) return false;

  const cuerpo = limpio.slice(0, -1);
  const digitoVerificador = limpio.slice(-1);
  if (!/^\d+$/.test(cuerpo)) return false;

  let suma = 0;
  let multiplicador = 2;
  for (let i = cuerpo.length - 1; i >= 0; i--) {
    suma += Number(cuerpo[i]) * multiplicador;
    multiplicador = multiplicador === 7 ? 2 : multiplicador + 1;
  }

  const resto = 11 - (suma % 11);
  const esperado = resto === 11 ? "0" : resto === 10 ? "K" : String(resto);

  return digitoVerificador === esperado;
}

/**
 * Marca un campo como inválido: le agrega la clase "con-error" a
 * su .grupo-form (classList.add) y crea/actualiza el mensaje de
 * error con createElement + textContent.
 */
function errorCampo(input, mensaje) {
  const grupo = input.closest(".grupo-form");
  if (!grupo) return;

  grupo.classList.add("con-error");
  input.setAttribute("aria-invalid", "true");

  let elementoError = grupo.querySelector(".error");
  if (!elementoError) {
    elementoError = document.createElement("div");
    elementoError.className = "error";
    grupo.append(elementoError);
  }
  elementoError.textContent = mensaje;
}

function limpiarError(input) {
  const grupo = input.closest(".grupo-form");
  if (!grupo) return;

  grupo.classList.remove("con-error");
  input.removeAttribute("aria-invalid");

  const elementoError = grupo.querySelector(".error");
  if (elementoError) elementoError.remove();
}

function configurarFormularioLogin() {
  const formulario = document.getElementById("form-login");
  if (!formulario) return;

  formulario.addEventListener("submit", (evento) => {
    evento.preventDefault();

    const correo = formulario.correo;
    const clave = formulario.clave;
    limpiarError(correo);
    limpiarError(clave);
    let esValido = true;

    if (!correo.value.trim()) {
      errorCampo(correo, "El correo es obligatorio.");
      esValido = false;
    } else if (correo.value.length > 100 || !validarCorreo(correo.value)) {
      errorCampo(correo, "Usa un correo @duoc.cl, @profesor.duoc.cl o @gmail.com.");
      esValido = false;
    }

    if (!clave.value) {
      errorCampo(clave, "La contraseña es obligatoria.");
      esValido = false;
    } else if (clave.value.length < 4 || clave.value.length > 10) {
      errorCampo(clave, "La contraseña debe tener entre 4 y 10 caracteres.");
      esValido = false;
    }

    if (esValido) {
      localStorage.setItem("usuarioActivo", correo.value);
      mostrarNotificacion("Inicio de sesión correcto.");
      location.href = "index.html";
    }
  });
}

function configurarFormularioRegistro() {
  const formulario = document.getElementById("form-registro");
  if (!formulario) return;

  formulario.addEventListener("submit", (evento) => {
    evento.preventDefault();

    const campos = [
      formulario.run,
      formulario.nombre,
      formulario.apellidos,
      formulario.correo,
      formulario.clave,
      formulario.region,
      formulario.comuna
    ];
    campos.forEach(limpiarError);
    let esValido = true;

    if (!validarRUN(formulario.run.value)) {
      errorCampo(formulario.run, "RUN no válido.");
      esValido = false;
    }
    if (!formulario.nombre.value.trim() || formulario.nombre.value.length > 100) {
      errorCampo(formulario.nombre, "Ingresa un nombre válido de máximo 100 caracteres.");
      esValido = false;
    }
    if (!formulario.apellidos.value.trim() || formulario.apellidos.value.length > 100) {
      errorCampo(formulario.apellidos, "Ingresa apellidos válidos de máximo 100 caracteres.");
      esValido = false;
    }
    if (!validarCorreo(formulario.correo.value) || formulario.correo.value.length > 100) {
      errorCampo(formulario.correo, "Correo no permitido.");
      esValido = false;
    }
    if (formulario.clave.value.length < 4 || formulario.clave.value.length > 10) {
      errorCampo(formulario.clave, "La contraseña debe tener entre 4 y 10 caracteres.");
      esValido = false;
    }
    if (!formulario.region.value) {
      errorCampo(formulario.region, "Selecciona una región.");
      esValido = false;
    }
    if (!formulario.comuna.value) {
      errorCampo(formulario.comuna, "Selecciona una comuna.");
      esValido = false;
    }
    if (!formulario.terminos.checked) {
      mostrarNotificacion("Debes aceptar los términos y condiciones para registrarte.", "error");
      esValido = false;
    }

    if (esValido) {
      mostrarNotificacion("Usuario registrado correctamente.");
      formulario.reset();
    }
  });
}

function configurarFormularioContacto() {
  const formulario = document.getElementById("form-contacto");
  if (!formulario) return;

  formulario.addEventListener("submit", (evento) => {
    evento.preventDefault();

    const nombre = formulario.nombre;
    const correo = formulario.correo;
    const comentario = formulario.comentario;
    [nombre, correo, comentario].forEach(limpiarError);
    let esValido = true;

    if (!nombre.value.trim() || nombre.value.length > 100) {
      errorCampo(nombre, "El nombre es obligatorio y máximo 100 caracteres.");
      esValido = false;
    }
    if (!validarCorreo(correo.value) || correo.value.length > 100) {
      errorCampo(correo, "Correo no permitido.");
      esValido = false;
    }
    if (!comentario.value.trim() || comentario.value.length > 500) {
      errorCampo(comentario, "El comentario es obligatorio y máximo 500 caracteres.");
      esValido = false;
    }

    if (esValido) {
      // textContent, no innerHTML: el mensaje se arma acá mismo,
      // pero igual es buena práctica usar textContent con texto plano.
      const mensajeExito = document.getElementById("mensaje-contacto");
      if (mensajeExito) {
        mensajeExito.textContent = "Mensaje enviado correctamente. Gracias por contactarnos.";
      }
      formulario.reset();
    }
  });
}

function configurarFormularioProducto() {
  const formulario = document.getElementById("form-producto");
  if (!formulario) return;

  formulario.addEventListener("submit", (evento) => {
    evento.preventDefault();

    const datos = new FormData(formulario);
    const producto = {
      id: datos.get("codigo").trim(),
      categoria: datos.get("categoria"),
      nombre: datos.get("nombre").trim(),
      descripcion: datos.get("descripcion").trim(),
      precio: Number(datos.get("precio")),
      precioComercial: Number(datos.get("precioComercial") || datos.get("precio")),
      stock: Number(datos.get("stock")),
      imagen: "img/producto.svg"
    };

    const productos = obtenerProductos();
    const indiceExistente = productos.findIndex((p) => p.id === producto.id);

    if (indiceExistente >= 0) {
      productos[indiceExistente] = producto;
    } else {
      productos.push(producto);
    }

    guardarProductos(productos);
    mostrarNotificacion("Producto guardado correctamente.");
    location.href = "productos.html";
  });
}

function configurarFormularioUsuario() {
  const formulario = document.getElementById("form-usuario");
  if (!formulario) return;

  formulario.addEventListener("submit", (evento) => {
    evento.preventDefault();

    const run = formulario.run;
    const nombre = formulario.nombre;
    const correo = formulario.correo;
    [run, nombre, correo].forEach(limpiarError);
    let esValido = true;

    if (!validarRUN(run.value)) {
      errorCampo(run, "RUN no válido.");
      esValido = false;
    }
    if (!nombre.value.trim() || nombre.value.length > 100) {
      errorCampo(nombre, "Nombre obligatorio y máximo 100 caracteres.");
      esValido = false;
    }
    if (!validarCorreo(correo.value) || correo.value.length > 100) {
      errorCampo(correo, "Correo no permitido.");
      esValido = false;
    }

    if (esValido) {
      const usuarios = obtenerUsuarios();
      usuarios.push({
        run: run.value,
        nombre: nombre.value,
        correo: correo.value,
        rol: formulario.rol.value,
        activo: true
      });
      guardarUsuarios(usuarios);
      mostrarNotificacion("Usuario guardado correctamente.");
      location.href = "usuarios.html";
    }
  });
}

function configurarFormularios() {
  configurarFormularioLogin();
  configurarFormularioRegistro();
  configurarFormularioContacto();
  configurarFormularioProducto();
  configurarFormularioUsuario();
}


/* ------------------------------------------------------------
   9. REGIÓN / COMUNA DEPENDIENTES
   ------------------------------------------------------------ */

const comunasPorRegion = {
  nuble: ["Chillán", "Chillán Viejo", "Bulnes", "Quillón", "El Carmen", "Pinto", "San Ignacio"],
  biobio: ["Los Ángeles", "Concepción"],
  araucania: ["Temuco"]
};

function actualizarComunas() {
  const selectorRegion = document.getElementById("region");
  const selectorComuna = document.getElementById("comuna");
  if (!selectorRegion || !selectorComuna) return;

  const comunas = comunasPorRegion[selectorRegion.value] || [];
  const opciones = comunas.map((comuna) => `<option>${comuna}</option>`).join("");
  selectorComuna.innerHTML = '<option value="">Seleccione una comuna</option>' + opciones;
}

function activarSelectorRegion() {
  const selectorRegion = document.getElementById("region");
  if (selectorRegion) selectorRegion.addEventListener("change", actualizarComunas);
}


/* ------------------------------------------------------------
   10. PANEL ADMINISTRADOR
   ------------------------------------------------------------ */

function filaProductoAdmin(producto) {
  const stockCritico = producto.stock <= 10;

  return `
    <tr>
      <td>${producto.id}</td>
      <td>${producto.nombre}</td>
      <td>${producto.categoria}</td>
      <td>${formatoPrecio(producto.precio)}</td>
      <td>${producto.stock}</td>
      <td><span class="estado ${stockCritico ? "critico" : ""}">${stockCritico ? "Stock crítico" : "Disponible"}</span></td>
      <td>
        <a class="btn btn-secundario btn-pequeno" href="producto.html?id=${producto.id}">Editar</a>
        <button class="btn btn-peligro btn-pequeno" data-accion="eliminar-producto" data-id="${producto.id}">
          Eliminar
        </button>
      </td>
    </tr>
  `;
}

function renderAdminProductos() {
  const cuerpoTabla = document.getElementById("tabla-productos");
  if (!cuerpoTabla) return;

  cuerpoTabla.innerHTML = obtenerProductos().map(filaProductoAdmin).join("");
}

function usuariosDeEjemplo() {
  return [
    { run: "12.345.678-5", nombre: "Administrador Demo", correo: "admin@gmail.com", rol: "Administrador", activo: true },
    { run: "11.111.111-1", nombre: "Operadora Demo", correo: "operadora@duoc.cl", rol: "Operadora / Despachadora", activo: true },
    { run: "10.222.333-4", nombre: "Repartidor Demo", correo: "repartidor@gmail.com", rol: "Repartidor", activo: true }
  ];
}

function renderAdminUsuarios() {
  const cuerpoTabla = document.getElementById("tabla-usuarios");
  if (!cuerpoTabla) return;

  const usuarios = obtenerUsuarios().length ? obtenerUsuarios() : usuariosDeEjemplo();

  cuerpoTabla.innerHTML = usuarios
    .map(
      (usuario) => `
        <tr>
          <td>${usuario.run}</td>
          <td>${usuario.nombre}</td>
          <td>${usuario.correo}</td>
          <td>${usuario.rol}</td>
          <td>${usuario.activo ? "Activo" : "Inactivo"}</td>
        </tr>
      `
    )
    .join("");
}

function renderDashboard() {
  const totalProductos = document.getElementById("total-productos");
  const stockCritico = document.getElementById("stock-critico");
  const totalCarrito = document.getElementById("total-carrito");

  const productos = obtenerProductos();

  if (totalProductos) totalProductos.textContent = productos.length;
  if (stockCritico) stockCritico.textContent = productos.filter((p) => p.stock <= 10).length;
  if (totalCarrito) totalCarrito.textContent = obtenerCarrito().reduce((suma, p) => suma + p.cantidad, 0);
}

/** Si la URL trae ?id=..., precarga ese producto en el formulario de edición. */
function cargarProductoAdmin() {
  const formulario = document.getElementById("form-producto");
  if (!formulario) return;

  const id = new URLSearchParams(location.search).get("id");
  if (!id) return;

  const producto = obtenerProductos().find((p) => p.id === id);
  if (!producto) return;

  formulario.codigo.value = producto.id;
  formulario.nombre.value = producto.nombre;
  formulario.categoria.value = producto.categoria;
  formulario.precio.value = producto.precio;
  formulario.precioComercial.value = producto.precioComercial;
  formulario.stock.value = producto.stock;
  formulario.descripcion.value = producto.descripcion;
}

function eliminarProductoAdmin(id) {
  const productos = obtenerProductos().filter((p) => p.id !== id);
  guardarProductos(productos);
  renderAdminProductos();
  renderDashboard();
  mostrarNotificacion("Producto eliminado.");
}


/* ------------------------------------------------------------
   11. DELEGACIÓN DE EVENTOS
   En vez de usar onclick="..." dentro del HTML generado (mala
   práctica según la guía), todos los botones dinámicos llevan un
   atributo data-accion. Un único listener escucha los clics de
   toda la página y decide qué hacer según event.target.
   ------------------------------------------------------------ */

function inicializarEventosGlobales() {
  document.addEventListener("click", (evento) => {
    const botón = evento.target.closest("[data-accion]");
    if (!botón) return;

    const id = botón.dataset.id;

    switch (botón.dataset.accion) {
      case "agregar-carrito":
        agregarCarrito(id);
        break;

      case "agregar-desde-detalle":
        agregarDesdeDetalle(id);
        break;

      case "restar-cantidad":
        cambiarCantidad(id, -1);
        break;

      case "sumar-cantidad":
        cambiarCantidad(id, 1);
        break;

      case "eliminar-item":
        eliminarCarrito(id);
        break;

      case "finalizar-pedido":
        finalizarPedido(botón);
        break;

      case "eliminar-producto":
        eliminarProductoAdmin(id);
        break;

      default:
        break;
    }
  });
}


/* ------------------------------------------------------------
   12. CARGA ASÍNCRONA DEL CATÁLOGO (fetch + Promise)
   Intenta traer el catálogo desde data/productos.json. Si el
   archivo no existe o falla la red, sencillamente seguimos
   usando productosIniciales (ya cargado por defecto), así que
   el sitio nunca se rompe por un problema de conexión.
   ------------------------------------------------------------ */

function cargarCatalogoDesdeServidor() {
  const yaHayCatalogoGuardado = localStorage.getItem("productosGas");
  const versionGuardada = localStorage.getItem("catalogoVersion");
  const catalogoDesactualizado = versionGuardada !== CATALOGO_VERSION;

  // Si ya hay catálogo guardado Y sigue en la misma versión, lo respetamos
  // (para no pisar cambios hechos desde el admin). Si la versión cambió,
  // volvemos a pedirlo al servidor aunque ya hubiera algo guardado.
  if (yaHayCatalogoGuardado && !catalogoDesactualizado) return;

  fetch("data/productos.json")
    .then((respuesta) => {
      if (!respuesta.ok) throw new Error("No se pudo leer el catálogo del servidor.");
      return respuesta.json();
    })
    .then((productos) => {
      guardarProductos(productos);
      localStorage.setItem("catalogoVersion", CATALOGO_VERSION);
      // Se re-dibuja todo lo que ya se haya pintado con los datos por defecto
      renderDestacados();
      renderProductos();
      renderDetalle();
      renderAdminProductos();
      renderDashboard();
    })
    .catch((error) => {
      console.warn("Usando catálogo local de respaldo:", error.message);
    });
}


/* ------------------------------------------------------------
   13. ARRANQUE DE LA APLICACIÓN
   ------------------------------------------------------------ */

document.addEventListener("DOMContentLoaded", () => {
  activarMenu();
  actualizarContador();

  renderDestacados();
  renderProductos();
  renderDetalle();
  renderCarrito();

  renderAdminProductos();
  renderAdminUsuarios();
  renderDashboard();
  cargarProductoAdmin();

  configurarFormularios();
  activarSelectorRegion();
  inicializarEventosGlobales();

  cargarCatalogoDesdeServidor();
});
