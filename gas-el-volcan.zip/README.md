# Gas El Volcán - Evaluación Parcial 1

Proyecto académico para DSY1104.

Tecnologías:
- HTML5
- CSS externo
- JavaScript Vanilla
- Node.js para servidor local

## Ejecutar

1. Abrir la carpeta en Visual Studio Code.
2. Abrir una terminal en la carpeta.
3. Ejecutar `npm start`.
4. Abrir `http://localhost:3000`.

No utiliza React ni frameworks de frontend. El carrito utiliza localStorage.
